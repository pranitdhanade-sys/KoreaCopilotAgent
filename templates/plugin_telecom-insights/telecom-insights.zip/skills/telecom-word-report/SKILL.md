---
name: telecom-word-report
description: |
  Generates a structured Microsoft Word (.docx) report from telecom customer analysis results.
  Use when the user asks to create a "Word 보고서", "워드 문서", ".docx 보고서", "보고서 작성",
  "공식 보고서", "임원 보고용 문서", "Word document", "executive write-up", or any time the
  user requests a printable narrative document about telecom customer analysis. This skill
  receives the structured analysis payload produced by `telecom-customer-analysis` and emits a
  formatted Word document with cover page, executive summary, sectioned insights, recommended
  actions, and an appendix. Do not use for slide decks (use `telecom-ppt-report`) or
  interactive dashboards (use `telecom-dashboard-builder`).
license: MIT
metadata:
  author: Microsoft Demo
  version: "1.0"
---

# Telecom Word Report

## What This Skill Does

`telecom-customer-analysis` 의 분석 페이로드를 받아 임원/현업 공유용 **Word 보고서(.docx)** 를 생성합니다. Cowork의 내장 문서 생성 기능을 사용하므로 본 스킬은 **문서 구조 + 섹션 콘텐츠 + 표/차트 지시** 를 마크다운 페이로드로 작성해 전달합니다.

## Inputs (분석 페이로드)

`telecom-customer-analysis/SKILL.md` 의 출력 형식과 동일:

- 분석 개요 (주제 / 기간 / 표본 크기 / 데이터 출처)
- 핵심 KPI 표
- 세그먼트 비교 표
- 인사이트 3개 + 권장 액션 2~3개
- 사용된 SQL

## Workflow

1. **메타데이터 확정** — 보고서 제목, 작성일, 작성자(Cowork via Telecom Insights), 수신자(사용자 지정 또는 "관계자"). 사용자가 수신자/제목을 명시하지 않았다면 한 번만 묻고 진행.
2. **문서 구조 빌드** — `references/word-template.md` 의 8-섹션 구조에 맞춰 콘텐츠 슬롯을 채웁니다.
3. **표/차트 처리** —
   - 표는 마크다운 표로 작성(Cowork가 docx의 Word 표로 변환).
   - 차트는 본문에 포함하지 않고, 필요시 "<여기에 막대차트: 제조사 × 평균 충성도>" 같은 **차트 자리 표시자 캡션** 으로 명시해 사용자가 직접 삽입 가능하게.
4. **Cowork 내장 docx 생성 호출** — 위 구조화된 마크다운을 Cowork의 문서 생성기에 전달하여 `.docx` 로 변환. 본 스킬 안에서 Python/스크립트로 직접 docx 바이너리를 만들지 마세요.
5. **자기 검증** — 생성 후:
   - 모든 섹션 헤딩이 일관된 레벨(H1 표지, H2 섹션)
   - 표 각 행의 셀 수가 헤더와 일치
   - SQL 부록이 코드 블록(고정폭 글꼴)으로 들어갔는지
6. **사용자 전달 및 메일 분기** — 파일을 `통신_고객_분석_보고서_YYYYMMDD.docx` 명으로 전달. 사용자가 "메일로 보내줘" 라고 하면 **Cowork 내장 Outlook 기능에 첨부 위임** (본 스킬에서 직접 발송 시도 금지).

## Output Format (문서 구조)

`references/word-template.md` 참고. 항상 다음 순서:

1. **표지** — 제목 / 부제 / 작성일 / 데이터 출처
2. **Executive Summary** — 5~7줄 요약(핵심 발견 + 권장 액션 한 문장씩)
3. **분석 개요** — 목적, 데이터 범위, 표본 크기, 방법론
4. **핵심 KPI** — 표 + 1줄 해석
5. **세그먼트 심층 분석** — 패턴(P1~P7) 중 해당하는 항목별 sub-섹션(2~4개)
6. **주요 인사이트** — 번호 매김 3개, 각 인사이트 1단락
7. **권장 액션** — 리텐션 / 업셀 / CS 카테고리로 분류, 각 액션의 타깃 세그먼트 + 기대 효과
8. **부록** — A. 데이터 스키마 요약 / B. 사용된 SQL / C. 용어집

## Additional Resources

- **`references/word-template.md`** — 8개 섹션 각각의 구조화 마크다운 템플릿. 자리 표시자(`__TITLE__`, `__EXEC_SUMMARY__` 등)를 분석 페이로드로 치환.

## Guardrails

- **공식 문서 톤** — 캐주얼한 이모지/속어 금지. "~합니다", "~로 분석됨" 등 객체적 어조.
- **수치 단위 명시** — 모든 숫자에 단위(GB / % / 원 / 개월 / 회). 큰 숫자는 천 단위 콤마.
- **PII 노출 금지** — `Customer_ID` 는 본문에 노출하지 말고, 추출이 필요하면 "1,234명" 처럼 인원수 단위로.
- **데이터 한계 명시** — 표지 또는 분석 개요에서 "표본 1,000행 더미 데이터" 명시(1회).
- **이중 보고 금지** — 본 스킬은 Word만 만듭니다. PPT/HTML 동시 생성은 사용자가 명시적으로 요청한 경우에만 각 스킬을 별도 호출.
