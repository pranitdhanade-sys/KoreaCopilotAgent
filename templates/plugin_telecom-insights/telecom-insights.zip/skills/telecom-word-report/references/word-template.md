# Word Report Template — Telecom Customer Insights

`telecom-word-report` 가 Cowork 내장 문서 생성기에 전달하는 **구조화 마크다운** 템플릿입니다. 자리 표시자(`__...__`)를 분석 페이로드로 치환합니다.

## 자리 표시자

| 자리 표시자 | 값 |
| --- | --- |
| `__TITLE__` | 보고서 제목 (예: "통신사 고객 이탈 위험 분석 보고서") |
| `__SUBTITLE__` | 부제 (예: "5G 가입자 1,000명 표본 기반") |
| `__GENERATED_AT__` | 작성일 (예: "2026년 5월 20일") |
| `__AUTHOR__` | "Cowork · Telecom Customer Insights Plugin" |
| `__RECIPIENT__` | 수신자 (사용자 지정, 없으면 "관계자 제위") |
| `__EXEC_SUMMARY__` | 5~7줄 요약 문단 |
| `__SCOPE__` | 분석 범위 한 문단 |
| `__METHODOLOGY__` | 방법론 (어떤 도구·쿼리·휴리스틱) 한 문단 |
| `__KPI_TABLE_ROWS__` | KPI 표 본문 행들 |
| `__KPI_INTERPRETATION__` | KPI 1줄 해석 |
| `__SEGMENT_SECTIONS__` | 세그먼트별 sub-섹션들 (반복) |
| `__INSIGHT_PARAGRAPHS__` | 번호 매긴 인사이트 단락 3개 |
| `__RETENTION_ACTIONS__` | 리텐션 액션 글머리표 |
| `__UPSELL_ACTIONS__` | 업셀 액션 글머리표 |
| `__CS_ACTIONS__` | CS 액션 글머리표 |
| `__SCHEMA_SUMMARY__` | 데이터 스키마 요약 표 |
| `__SQL_USED__` | 사용된 SQL 코드 블록 |
| `__GLOSSARY__` | 용어집 |

## 본문 템플릿

```markdown
# __TITLE__
## __SUBTITLE__

> 작성일: __GENERATED_AT__
> 작성: __AUTHOR__
> 수신: __RECIPIENT__
> 데이터 출처: Telecom DB MCP (`devices` 테이블, 표본 1,000행 더미 데이터)

---

## 1. Executive Summary

__EXEC_SUMMARY__

---

## 2. 분석 개요

### 2.1 분석 범위

__SCOPE__

### 2.2 방법론

__METHODOLOGY__

본 분석은 Microsoft 365 Copilot Cowork의 Telecom Customer Insights 플러그인을 통해
Telecom DB MCP의 `get-table-schema`, `get-device-stats`, `run-sql` 도구를 호출하여
수행되었습니다.

---

## 3. 핵심 KPI

| 지표 | 값 | 비고 |
| --- | --- | --- |
__KPI_TABLE_ROWS__

> __KPI_INTERPRETATION__

---

## 4. 세그먼트 심층 분석

__SEGMENT_SECTIONS__

---

## 5. 주요 인사이트

__INSIGHT_PARAGRAPHS__

---

## 6. 권장 액션

### 6.1 리텐션 (Retention)

__RETENTION_ACTIONS__

### 6.2 업셀 (Upsell)

__UPSELL_ACTIONS__

### 6.3 CS / 운영 개선

__CS_ACTIONS__

---

## 부록 A. 데이터 스키마 요약

__SCHEMA_SUMMARY__

## 부록 B. 사용된 SQL

```sql
__SQL_USED__
```

## 부록 C. 용어집

__GLOSSARY__
```

## 세그먼트 sub-섹션 패턴

`__SEGMENT_SECTIONS__` 자리에 다음 패턴을 분석 패턴 수만큼 반복:

```markdown
### 4.x <세그먼트 이름>

**정의**: <어떤 조건의 고객인가, 1~2줄>

**규모**: <인원 수 + 전체 대비 비중>

**핵심 지표**:

| 지표 | 본 세그먼트 | 전체 평균 | 차이 |
| --- | --- | --- | --- |
| ... | ... | ... | ... |

**해석**: <왜 이 세그먼트가 중요한가, 2~3줄>

> [차트 자리: <차트 종류> — <축/시리즈 설명>]
```

## 액션 글머리표 패턴

```markdown
- **타깃**: <세그먼트 + 인원>
  - **액션**: <구체 행동 1줄>
  - **기대 효과**: <정량 가설, 예: "이탈률 -3%p, ARPU +5%">
  - **실행 주체**: <담당 부서>
```

## 용어집 예시 (`__GLOSSARY__`)

```markdown
| 용어 | 정의 |
| --- | --- |
| ARPU | Average Revenue Per User. 가입자 1인당 월평균 매출. |
| 이탈 위험군 | 약정 종료 임박 + 단말 노후 + 낮은 충성도 조건 중 2개 이상 충족. |
| 락인 (Lock-in) | 결합 상품, 약정, 보조금 등으로 인한 가입 유지 효과. |
| 충성도 점수 | Brand_Loyalty_Score 컬럼. 1(낮음)~10(높음) 정수. |
| 교체 주기 초과 | `Months_in_Use` 가 `Avg_Replacement_Cycle_Months` 를 넘은 상태. |
```

## 작성 톤 가이드

- 한국어 어미: "~합니다 / ~로 분석됨 / ~할 필요가 있습니다" 등 객체적 종결.
- 추측은 "추정됩니다", "시사합니다" 로 표시하여 결정과 구분.
- 한 단락은 4~6줄 이내. 길어지면 글머리표로 분해.
- 같은 수치를 본문과 표에 모두 쓰지 말고, 표로 보일 수 있으면 본문은 해석으로.
