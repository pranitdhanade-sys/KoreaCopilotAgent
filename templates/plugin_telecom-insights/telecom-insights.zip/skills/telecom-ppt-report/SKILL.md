---
name: telecom-ppt-report
description: |
  Generates a Microsoft PowerPoint (.pptx) slide deck from telecom customer analysis results.
  Use when the user asks to build a "PPT 보고서", "파워포인트", "프레젠테이션", "슬라이드",
  "임원 발표 자료", "보고용 슬라이드 덱", "slide deck", "PowerPoint presentation", or any
  visual presentation about telecom customer analysis. This skill receives the structured
  analysis payload produced by `telecom-customer-analysis` and emits a 9-slide deck spec
  (title / agenda / executive summary / KPI / segment analysis / risk / actions / next steps /
  appendix) for Cowork's built-in slide generator. Do not use for printable documents (use
  `telecom-word-report`) or interactive dashboards (use `telecom-dashboard-builder`).
license: MIT
metadata:
  author: Microsoft Demo
  version: "1.0"
---

# Telecom PPT Report

## What This Skill Does

`telecom-customer-analysis` 의 분석 페이로드를 받아 8~10장 분량의 **PowerPoint 슬라이드 덱(.pptx)** 을 생성합니다. Cowork의 내장 슬라이드 생성 기능을 사용하므로 본 스킬은 **슬라이드 시퀀스 + 각 슬라이드의 레이아웃·메시지·차트 종류** 를 명세 형태로 작성해 전달합니다.

## Inputs (분석 페이로드)

`telecom-customer-analysis/SKILL.md` 의 출력 형식과 동일.

## Workflow

1. **메타 확정** — 덱 제목, 발표 일자, 발표자(또는 "Cowork · Telecom Insights"), 청중(임원/현업) 1회 확인 후 진행.
2. **슬라이드 시퀀스 빌드** — `references/ppt-template.md` 의 9-슬라이드 패턴에 맞춰 콘텐츠 슬롯 채우기. 분석 패턴별 권장 슬라이드 수 가이드:
   | 분석 범위 | 슬라이드 수 |
   | --- | --- |
   | 단일 패턴(P1~P7 중 1개) | 8장 |
   | 2~3 패턴 결합 | 10장 |
   | 종합 임원 보고 | 12장 (각 패턴 1장 + 종합) |
3. **차트 지정** — 각 슬라이드의 차트 자리에 **차트 종류 + 데이터 라벨/값** 을 명시. (예: "Bar chart, X=제조사, Y=평균 충성도, 데이터: Samsung 7.4 / Apple 7.1 / Xiaomi 5.8 / Google 6.5")
4. **Cowork 내장 슬라이드 생성 호출** — 위 명세를 Cowork의 슬라이드 생성기에 전달. 본 스킬에서 python-pptx 등으로 직접 바이너리를 만들지 마세요.
5. **자기 검증** —
   - 슬라이드 번호가 1부터 연속
   - 각 슬라이드의 헤드라인이 한 문장으로 핵심 메시지 전달(단순 명사구 금지)
   - 차트와 표가 같은 슬라이드에 함께 들어가지 않도록(가독성)
6. **사용자 전달 및 메일 분기** — `통신_고객_분석_YYYYMMDD.pptx` 명으로 전달. "메일로 보내줘" 요청 시 **Cowork 내장 Outlook 기능에 첨부 위임**.

## Output Format (덱 구조)

`references/ppt-template.md` 참고. 표준 9-슬라이드 시퀀스:

| # | 슬라이드 | 레이아웃 | 핵심 메시지 |
| -- | --- | --- | --- |
| 1 | 표지 | Title Slide | 보고서 제목 + 부제 + 일자 + 발표자 |
| 2 | Agenda | Title + Content | 본 발표가 다룰 4~6개 주제 |
| 3 | Executive Summary | Title + Big Number Strip | 핵심 KPI 3개 + 한 줄 결론 |
| 4 | 분석 개요 | Title + Content | 데이터 출처/표본/방법론 |
| 5 | 핵심 KPI 상세 | Title + Chart | KPI Bar/Line 차트 + 1줄 인사이트 |
| 6 | 세그먼트 비교 | Title + Table | 세그먼트별 핵심 지표 표 + 강조 행 |
| 7 | 주요 인사이트 | Title + 3-Column | 인사이트 3개를 카드 형식으로 |
| 8 | 권장 액션 | Title + 3-Column | 리텐션 / 업셀 / CS 액션 |
| 9 | 부록 / Q&A | Title + Code | 사용된 SQL 요약 + 데이터 한계 노트 |

## Additional Resources

- **`references/ppt-template.md`** — 9-슬라이드 각각의 레이아웃·요소·예시 텍스트 + 차트 명세 패턴.

## Guardrails

- **한 슬라이드 한 메시지** — 슬라이드 헤드라인은 결론 문장(예: "고가단말 고객의 충성도가 가장 높습니다"). 단순 "충성도 분석" 같은 명사구 금지.
- **텍스트 분량** — 슬라이드당 본문 텍스트 100자 이내. 길어지면 표나 글머리표로 분해.
- **차트 우선** — 가능하면 수치는 차트로. 표는 8행 이내.
- **수치 단위 일관성** — 모든 수치에 단위. 큰 수는 천 단위 콤마.
- **PII 노출 금지** — `Customer_ID` 노출 금지. 세그먼트는 항상 집계 단위.
- **표지/마지막 슬라이드 통일성** — 표지의 색·폰트와 마지막 슬라이드가 동일한 톤(Cowork 슬라이드 생성기의 기본 테마 유지).
