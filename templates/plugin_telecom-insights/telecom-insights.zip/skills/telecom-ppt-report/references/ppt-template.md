# PPT Slide Template — Telecom Customer Insights

`telecom-ppt-report` 가 Cowork 내장 슬라이드 생성기에 전달하는 **슬라이드 명세** 입니다. 각 슬라이드는 레이아웃 키워드 + 헤드라인 + 콘텐츠 슬롯으로 정의합니다.

## 표준 9-슬라이드 시퀀스

각 슬라이드를 아래 마크다운 명세 형태로 작성하여 Cowork에 전달합니다.

---

### Slide 1 — 표지 (Title Slide)

```markdown
[Slide 1 / Layout: Title Slide]
Title: __TITLE__ (예: "통신사 고객 이탈 위험 분석")
Subtitle: __SUBTITLE__ (예: "5G 가입자 1,000명 표본 기반 인사이트")
Footer: __GENERATED_AT__ · __AUTHOR__ · Cowork Telecom Insights Plugin
```

---

### Slide 2 — Agenda

```markdown
[Slide 2 / Layout: Title + Content]
Headline: 오늘 다룰 4가지 주제
Bullets:
1. 분석 개요 — 데이터 출처와 방법론
2. 핵심 KPI — 가입자 사용/충성도 현황
3. 세그먼트 심층 분석 — 이탈 위험군 식별
4. 권장 액션 — 리텐션/업셀/CS 우선순위
```

---

### Slide 3 — Executive Summary

```markdown
[Slide 3 / Layout: Title + Big Number Strip]
Headline: <결론 한 문장> (예: "이탈 위험 23% 고객을 대상으로 한 결합 프로모션이 시급합니다")
Big Numbers (3개):
  - 1,000명 / 표본 가입자
  - 23% / 이탈 위험군 비중
  - 7.2 / 평균 충성도 (10점 만점)
Footnote: 출처: Telecom DB MCP · 1,000행 더미 데이터
```

---

### Slide 4 — 분석 개요

```markdown
[Slide 4 / Layout: Title + Two Column]
Headline: 1,000명 5G 가입자, 33개 속성을 분석했습니다
Left Column — 데이터 범위:
  - 표본: 1,000명 (전체 가입자 더미)
  - 컬럼: 단말 33개 속성 (스펙/사용/충성도/채널)
  - 기간: 활성 가입 시점 기준
Right Column — 방법론:
  - Telecom DB MCP `run-sql` 12개 쿼리
  - 이탈/충성/사용 패턴 7개 분석 패턴
  - 휴리스틱 룰 + 백분위/NTILE 세그멘테이션
```

---

### Slide 5 — 핵심 KPI

```markdown
[Slide 5 / Layout: Title + Chart]
Headline: 평균 데이터 사용량은 41.2 GB, 충성도는 7.2점입니다
Chart:
  Type: Bar
  Title: 핵심 KPI 요약
  X: ["데이터(GB)","충성도(점)","결합 가입율(%)","약정 잔여(개월)"]
  Y: [41.2, 7.2, 58, 11]
  Color: #0078D4
Insight: 결합 가입율(58%)이 충성도와 강한 양의 상관을 보입니다.
```

---

### Slide 6 — 세그먼트 비교

```markdown
[Slide 6 / Layout: Title + Table]
Headline: 이탈 위험 High 세그먼트는 평균 충성도가 4.3점에 불과합니다
Table:
  Header: ["세그먼트","인원","평균 충성도","평균 사용 개월","평균 데이터(GB)"]
  Rows:
    - ["High Risk", "230명", "4.3", "27", "32.1"]
    - ["Medium Risk", "410명", "6.5", "18", "39.8"]
    - ["Low Risk", "360명", "8.7", "9", "45.6"]
Highlight: 첫 행(High Risk)을 빨강 배경으로 강조
Footnote: High Risk = 약정종료 임박 + 단말 노후 + 낮은 충성도 중 2개 이상
```

---

### Slide 7 — 주요 인사이트

```markdown
[Slide 7 / Layout: Title + 3 Column Cards]
Headline: 데이터에서 도출한 3가지 핵심 인사이트
Card 1:
  Tag: 이탈
  Title: 230명이 즉시 이탈 위험
  Text: 약정 종료가 임박하고 결합 상품에 가입하지 않은 230명이 가장 빠르게 이탈 가능.
Card 2:
  Tag: 사용
  Title: 야간 셀룰러 헤비 유저 12%
  Text: 22~02시 사용량 30GB 초과, Wi-Fi 비중 40% 미만인 그룹은 무제한 요금제 업셀 타깃.
Card 3:
  Tag: 충성
  Title: Family 결합이 충성도 +1.6점
  Text: 동일 단말가 대비 Family 결합 가입자의 충성도가 통계적으로 유의하게 높음.
```

---

### Slide 8 — 권장 액션

```markdown
[Slide 8 / Layout: Title + 3 Column Cards]
Headline: 3개 부서가 동시 실행할 우선 액션
Card 1 — 리텐션 (담당: 마케팅):
  - 타깃: High Risk 230명
  - 액션: Family 결합 1개월 무료 + 12개월 약정 프로모션 발송
  - 기대 효과: 이탈률 -3%p
Card 2 — 업셀 (담당: 상품):
  - 타깃: 야간 헤비 셀룰러 120명
  - 액션: 무제한 5G 요금제 + 콘텐츠 제휴 번들 권유
  - 기대 효과: ARPU +6%
Card 3 — CS (담당: 고객지원):
  - 타깃: 수리 3회 이상 + 보험 미가입 70명
  - 액션: 단말 보험 무료 1개월 + 사전 점검 캠페인
  - 기대 효과: 수리 재발률 -10%
```

---

### Slide 9 — 부록 / Q&A

```markdown
[Slide 9 / Layout: Title + Code]
Headline: 분석 재현용 SQL과 데이터 한계
Code Block (Title: "주요 SQL"):
  WITH scored AS ( ... )
  SELECT risk_tier, COUNT(*) FROM scored GROUP BY risk_tier;
Notes:
  - 본 분석은 1,000행 더미 데이터 기반이며, 실제 가입자 행동과 차이가 있을 수 있습니다.
  - 자세한 12개 쿼리는 Telecom Insights 플러그인 references/sql-cookbook.md 참고.
Closing: 감사합니다 · Q&A
```

---

## 차트 명세 패턴

차트가 들어가는 슬라이드는 다음 키-값 형식으로 작성:

```yaml
Chart:
  Type: Bar | Line | Pie | Doughnut | Stacked Bar | Horizontal Bar | Radar | Scatter
  Title: <차트 제목>
  X: [<라벨 배열>]
  Y: [<값 배열>] | Series: [{name: ..., data: [...]}]
  Color: <hex 또는 카테고리 팔레트 이름>
  Note (optional): <축 단위 / 데이터 출처>
```

## 슬라이드 헤드라인 작성 규칙

- **결론 문장** — "이탈 위험 23% 고객을 위해 결합 프로모션이 시급합니다." (○)
- **명사구 금지** — "이탈 위험 분석." (×)
- **수치 포함 권장** — 가능하면 슬라이드의 핵심 수치 1개를 헤드라인에 노출.
- **30자 내외** — 한 줄로 읽히는 길이.

## 분석 범위에 따른 슬라이드 추가

종합 임원 보고(12장)일 경우 다음 슬라이드를 5~6번 사이에 추가:

```markdown
[Slide 5a — P2 충성도 / Slide 5b — P3 사용 패턴 / Slide 5c — P4 번들·보조금]
각 슬라이드: Title + Chart(또는 Two Column)
```
