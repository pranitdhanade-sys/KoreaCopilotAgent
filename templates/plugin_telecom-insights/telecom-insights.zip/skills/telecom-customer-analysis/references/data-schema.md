# Telecom DB — Data Schema Reference

Telecom DB MCP의 `devices` 테이블은 단일 평면 테이블로, **고객당 1행**, 총 1,000행, 33개 컬럼입니다. SQL 작성 시 컬럼명은 대소문자/언더스코어를 정확히 일치시켜야 합니다(DuckDB).

## 컬럼 사전

| # | 컬럼 | 타입 | 의미 | 단위/예시값 |
| -- | --- | --- | --- | --- |
| 1 | `Customer_ID` | VARCHAR | 고객 익명 식별자 | `CUST_0001` |
| 2 | `Model_Code` | VARCHAR | 단말 모델 코드 | `SM-S921`, `A3106`, `G82U8`, `23127PN0CG` |
| 3 | `Model_Name` | VARCHAR | 단말 모델명 | `Galaxy S24`, `iPhone 15 Pro`, `Pixel 8`, `Xiaomi 14` |
| 4 | `Manufacturer` | VARCHAR | 제조사 | `Samsung`, `Apple`, `Google`, `Xiaomi` |
| 5 | `Release_Date` | DATE | 단말 출시일 | `2024-04-11` |
| 6 | `Activation_Date` | DATE | 고객 개통일 | `2024-08-14` |
| 7 | `Months_in_Use` | INTEGER | 개통 후 사용 개월 | `20` (개월) |
| 8 | `Launch_Price` | INTEGER | 단말 출고가 | `1,150,000` (원) |
| 9 | `Network_Type` | VARCHAR | 가입 네트워크 | `5G`, `LTE` |
| 10 | `OS_Version` | VARCHAR | 운영 체제 | `Android 14`, `iOS 17` |
| 11 | `Storage_Capacity_GB` | INTEGER | 저장 용량 | `128 / 256 / 512 / 1024` (GB) |
| 12 | `Battery_Health_Pct` | DOUBLE | 배터리 건강도 | `85.8` (%) — 100 초과 가능(보정 이슈) |
| 13 | `Display_Size_Inch` | DOUBLE | 디스플레이 크기 | `6.1 / 6.7 / 6.8` (인치) |
| 14 | `RAM_GB` | INTEGER | RAM 용량 | `6 / 8 / 12 / 16` (GB) |
| 15 | `Processor` | VARCHAR | AP/SoC | `Snapdragon Gen 3`, `A17 Pro` |
| 16 | `Camera_MP` | INTEGER | 메인 카메라 화소 | `48 / 50 / 108 / 200` (MP) |
| 17 | `Wireless_Charging` | VARCHAR | 무선 충전 지원 | `Yes` / `No` |
| 18 | `Biometric_Type` | VARCHAR | 생체 인증 종류 | `Fingerprint` / `Face ID` / `Both` |
| 19 | `Remaining_Installment` | INTEGER | 단말 할부 잔액 | 원. `0` 이면 완납 |
| 20 | `Avg_Data_Usage_GB` | DOUBLE | 월평균 데이터 사용량 | `41.25` (GB) |
| 21 | `Peak_Usage_Time` | VARCHAR | 최다 사용 시간대 (시:분) | `23:00`, `02:00` |
| 22 | `Wi_Fi_Ratio_Pct` | INTEGER | Wi-Fi 사용 비중 | `37` (%) — 셀룰러 대비 |
| 23 | `Roaming_Count_1Yr` | INTEGER | 최근 1년 로밍 횟수 | `1` (회) |
| 24 | `Tethering_Usage_GB` | DOUBLE | 월평균 테더링 사용량 | `10.11` (GB) |
| 25 | `Top_App_Category` | VARCHAR | 최다 사용 앱 카테고리 | `Game`, `Video`, `SNS`, `Business`, `Shopping`, `Finance` |
| 26 | `Connected_Devices_Count` | INTEGER | 연결 기기 수(워치/이어버드 등) | `1` (대) |
| 27 | `Brand_Loyalty_Score` | INTEGER | 브랜드 충성도 점수 | `1~10` (높을수록 충성) |
| 28 | `Avg_Replacement_Cycle_Months` | INTEGER | 평균 단말 교체 주기 | `31` (개월) |
| 29 | `Preferred_Channel` | VARCHAR | 선호 가입/구매 채널 | `Online Shop`, `Agency`, `Direct Store` |
| 30 | `Subsidy_Type` | VARCHAR | 보조금 유형 | `Selective Contract`(선택약정), `Device Subsidy`(공시지원금) |
| 31 | `Device_Insurance` | VARCHAR | 단말 보험 가입 여부 | `Yes` / `No` |
| 32 | `Trade_in_Program` | VARCHAR | 중고 보상 프로그램 가입 여부 | `Yes` / `No` |
| 33 | `Bundling_Status` | VARCHAR | 결합 상품 상태 | `Single`, `Family`, `Internet+TV` |
| 34 | `Repair_History_Count` | INTEGER | 누적 수리 횟수 | `3` (회) |

## 도메인 의미 노트

- **충성도와 교체 주기는 양의 상관**: `Brand_Loyalty_Score` 가 높을수록 같은 브랜드 내 재구매가 잦지만, `Avg_Replacement_Cycle_Months` 도 함께 길어지는 경향이 있습니다(만족 → 오래 사용).
- **`Battery_Health_Pct < 80` + `Months_in_Use ≥ 24`** 는 **교체 임박 세그먼트** 의 강력한 신호.
- **`Bundling_Status = 'Family'` 또는 `'Internet+TV'`** 는 가구 단위 락인 효과로 이탈률이 낮습니다.
- **`Subsidy_Type = 'Device Subsidy'`** 가입자는 약정 기간이 끝나는 24개월 전후로 번호이동/기변 의사가 급증합니다.
- **`Peak_Usage_Time` 22:00~02:00 + `Top_App_Category in ('Video', 'Game')`** 는 헤비 야간 사용자 = 데이터 무제한/요금제 업셀 타깃.
- **`Repair_History_Count ≥ 3`** 는 단말 보험 미가입자라면 CS 불만 위험군.

## 자주 쓰는 값 분포 (참고)

```text
Manufacturer:        Samsung / Apple / Xiaomi / Google
Network_Type:        5G (대다수), LTE
OS_Version:          Android 14, iOS 17
Top_App_Category:    Video > SNS > Game > Business > Shopping > Finance
Preferred_Channel:   Online Shop / Agency / Direct Store
Subsidy_Type:        Device Subsidy / Selective Contract
Bundling_Status:     Single / Family / Internet+TV
```
