# SQL Cookbook — Telecom DB `devices`

`run-sql` MCP 도구에 그대로 넣을 수 있는 **검증된 SELECT 쿼리** 모음입니다. 모두 단일 문장, 읽기 전용. 사용자의 추가 필터(제조사, 사용 기간 등)는 `WHERE` 절에 덧붙여 사용하세요.

> DuckDB 문법 기준. 컬럼명은 대소문자/언더스코어 정확히 일치 필요.

---

## Q1. 제조사별 가입자 분포 + 평균 충성도/사용량

```sql
SELECT
  Manufacturer,
  COUNT(*)                              AS customer_cnt,
  ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS share_pct,
  ROUND(AVG(Brand_Loyalty_Score), 2)    AS avg_loyalty,
  ROUND(AVG(Avg_Data_Usage_GB), 2)      AS avg_data_gb,
  ROUND(AVG(Battery_Health_Pct), 1)     AS avg_battery_pct,
  ROUND(AVG(Launch_Price), 0)           AS avg_price_krw
FROM devices
GROUP BY Manufacturer
ORDER BY customer_cnt DESC;
```

---

## Q2. 이탈 위험 세그멘테이션 (P1)

```sql
WITH scored AS (
  SELECT
    Customer_ID,
    Manufacturer,
    Model_Name,
    Months_in_Use,
    Battery_Health_Pct,
    Remaining_Installment,
    Subsidy_Type,
    Bundling_Status,
    Brand_Loyalty_Score,
    (CASE WHEN Months_in_Use >= 22 AND Remaining_Installment <= 200000 THEN 1 ELSE 0 END)
    + (CASE WHEN Battery_Health_Pct < 80 AND Months_in_Use >= 24 THEN 1 ELSE 0 END)
    + (CASE WHEN Bundling_Status = 'Single' AND Brand_Loyalty_Score <= 4 THEN 1 ELSE 0 END)
    AS risk_score
  FROM devices
)
SELECT
  CASE
    WHEN risk_score >= 2 THEN 'High'
    WHEN risk_score = 1  THEN 'Medium'
    ELSE 'Low'
  END AS risk_tier,
  COUNT(*) AS cnt,
  ROUND(AVG(Brand_Loyalty_Score), 2) AS avg_loyalty,
  ROUND(AVG(Months_in_Use), 1)       AS avg_months
FROM scored
GROUP BY risk_tier
ORDER BY CASE risk_tier WHEN 'High' THEN 0 WHEN 'Medium' THEN 1 ELSE 2 END;
```

---

## Q3. 충성도 5분위 × 결합 상품 가입율 (P2)

```sql
WITH quintile AS (
  SELECT
    Customer_ID,
    Bundling_Status,
    Avg_Replacement_Cycle_Months,
    NTILE(5) OVER (ORDER BY Brand_Loyalty_Score) AS loyalty_quintile
  FROM devices
)
SELECT
  loyalty_quintile,
  COUNT(*) AS customer_cnt,
  ROUND(100.0 * SUM(CASE WHEN Bundling_Status <> 'Single' THEN 1 ELSE 0 END) / COUNT(*), 1) AS bundled_pct,
  ROUND(AVG(Avg_Replacement_Cycle_Months), 1) AS avg_replace_months
FROM quintile
GROUP BY loyalty_quintile
ORDER BY loyalty_quintile;
```

---

## Q4. 데이터 사용량 백분위 + 앱 카테고리별 평균 (P3)

```sql
SELECT
  Top_App_Category,
  COUNT(*) AS cnt,
  ROUND(AVG(Avg_Data_Usage_GB), 2)             AS avg_gb,
  ROUND(quantile_cont(Avg_Data_Usage_GB, 0.5), 2) AS p50_gb,
  ROUND(quantile_cont(Avg_Data_Usage_GB, 0.9), 2) AS p90_gb,
  ROUND(AVG(Wi_Fi_Ratio_Pct), 1)               AS avg_wifi_pct,
  ROUND(AVG(Tethering_Usage_GB), 2)            AS avg_tether_gb
FROM devices
GROUP BY Top_App_Category
ORDER BY avg_gb DESC;
```

---

## Q5. 야간 헤비 셀룰러 사용자 추출 (P3)

```sql
SELECT
  Customer_ID,
  Manufacturer,
  Model_Name,
  Avg_Data_Usage_GB,
  Wi_Fi_Ratio_Pct,
  Peak_Usage_Time,
  Top_App_Category
FROM devices
WHERE Peak_Usage_Time IN ('22:00','23:00','00:00','01:00','02:00','03:00')
  AND Wi_Fi_Ratio_Pct < 40
  AND Avg_Data_Usage_GB > 30
ORDER BY Avg_Data_Usage_GB DESC
LIMIT 50;
```

---

## Q6. 번들링 상태 × 보조금 효과 (P4)

```sql
SELECT
  Bundling_Status,
  Subsidy_Type,
  COUNT(*) AS cnt,
  ROUND(AVG(Months_in_Use), 1)              AS avg_months_in_use,
  ROUND(AVG(Brand_Loyalty_Score), 2)        AS avg_loyalty,
  ROUND(100.0 * SUM(CASE WHEN Months_in_Use >= 22 THEN 1 ELSE 0 END) / COUNT(*), 1)
                                            AS end_of_contract_pct
FROM devices
GROUP BY Bundling_Status, Subsidy_Type
ORDER BY Bundling_Status, Subsidy_Type;
```

---

## Q7. 교체 주기 초과 고객 (P5)

```sql
SELECT
  Customer_ID,
  Manufacturer,
  Model_Name,
  Months_in_Use,
  Avg_Replacement_Cycle_Months,
  Months_in_Use - Avg_Replacement_Cycle_Months AS months_over_cycle,
  Battery_Health_Pct,
  Repair_History_Count
FROM devices
WHERE Months_in_Use >= Avg_Replacement_Cycle_Months
  AND Battery_Health_Pct <= 100
ORDER BY months_over_cycle DESC, Battery_Health_Pct ASC
LIMIT 50;
```

---

## Q8. 배터리 건강도 버킷별 수리 이력 (P5)

```sql
SELECT
  CASE
    WHEN Battery_Health_Pct < 70 THEN '<70'
    WHEN Battery_Health_Pct < 80 THEN '70-79'
    WHEN Battery_Health_Pct < 90 THEN '80-89'
    WHEN Battery_Health_Pct < 95 THEN '90-94'
    ELSE '95+'
  END AS battery_bucket,
  COUNT(*) AS cnt,
  ROUND(AVG(Months_in_Use), 1)            AS avg_months,
  ROUND(AVG(Repair_History_Count), 2)     AS avg_repairs
FROM devices
WHERE Battery_Health_Pct <= 100
GROUP BY battery_bucket
ORDER BY battery_bucket;
```

---

## Q9. 채널 × 보조금 매트릭스 (P6)

```sql
SELECT
  Preferred_Channel,
  Subsidy_Type,
  COUNT(*) AS cnt,
  ROUND(AVG(Launch_Price), 0)                 AS avg_price_krw,
  ROUND(100.0 * SUM(CASE WHEN Device_Insurance = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 1)
                                              AS insurance_pct,
  ROUND(100.0 * SUM(CASE WHEN Trade_in_Program = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 1)
                                              AS tradein_pct
FROM devices
GROUP BY Preferred_Channel, Subsidy_Type
ORDER BY Preferred_Channel, Subsidy_Type;
```

---

## Q10. 모델별 점유율 상위 10개 (P7)

```sql
SELECT
  Model_Name,
  Manufacturer,
  COUNT(*) AS cnt,
  ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS share_pct,
  ROUND(AVG(Brand_Loyalty_Score), 2)                AS avg_loyalty,
  ROUND(AVG(Months_in_Use), 1)                      AS avg_months
FROM devices
GROUP BY Model_Name, Manufacturer
ORDER BY cnt DESC
LIMIT 10;
```

---

## Q11. 무선충전·생체인증 옵션별 평균 출고가/충성도

```sql
SELECT
  Wireless_Charging,
  Biometric_Type,
  COUNT(*) AS cnt,
  ROUND(AVG(Launch_Price), 0)        AS avg_price_krw,
  ROUND(AVG(Brand_Loyalty_Score), 2) AS avg_loyalty
FROM devices
GROUP BY Wireless_Charging, Biometric_Type
ORDER BY avg_price_krw DESC;
```

---

## Q12. 로밍 사용자 프로파일

```sql
SELECT
  CASE
    WHEN Roaming_Count_1Yr = 0 THEN '0'
    WHEN Roaming_Count_1Yr BETWEEN 1 AND 2 THEN '1-2'
    WHEN Roaming_Count_1Yr BETWEEN 3 AND 5 THEN '3-5'
    ELSE '6+'
  END AS roaming_bucket,
  COUNT(*) AS cnt,
  ROUND(AVG(Avg_Data_Usage_GB), 2)   AS avg_data_gb,
  ROUND(AVG(Brand_Loyalty_Score), 2) AS avg_loyalty,
  ROUND(AVG(Launch_Price), 0)        AS avg_price_krw
FROM devices
GROUP BY roaming_bucket
ORDER BY roaming_bucket;
```

---

## 사용 팁

- 결과 행이 50개 이상이면 `LIMIT` 을 추가하거나 `GROUP BY` 로 요약하세요.
- 비율 계산은 `100.0 * SUM(CASE ... ) / COUNT(*)` 패턴을 사용합니다(정수 나눗셈 회피).
- 백분위는 `quantile_cont(col, q)` 사용(DuckDB).
- 두 개 이상의 분석 결과가 필요할 때는 별도 호출 — `run-sql` 은 단일 문장만 허용합니다.
