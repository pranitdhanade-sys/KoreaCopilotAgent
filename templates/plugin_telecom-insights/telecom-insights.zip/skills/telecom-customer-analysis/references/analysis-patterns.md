# Telecom Customer Analysis Patterns

`telecom-customer-analysis` 가 자주 받는 분석 요청을 7가지 패턴으로 분류하고, 각 패턴별로 핵심 컬럼/추천 도구/해석 가이드를 정리합니다. 각 패턴의 **검증된 SQL** 은 `sql-cookbook.md` 에 있습니다.

---

## P1. 이탈 위험 세그멘테이션

**언제 사용**: "이탈 위험 고객 찾아줘", "약정 종료 임박", "교체 임박 고객", "churn risk".

**핵심 컬럼**: `Months_in_Use`, `Remaining_Installment`, `Battery_Health_Pct`, `Subsidy_Type`, `Bundling_Status`, `Brand_Loyalty_Score`.

**룰 (휴리스틱)**:
- `Months_in_Use >= 22` AND `Remaining_Installment <= 200000` → 약정 종료 임박
- `Battery_Health_Pct < 80` AND `Months_in_Use >= 24` → 단말 노후 → 기변 신호
- `Bundling_Status = 'Single'` AND `Brand_Loyalty_Score <= 4` → 락인 약함
- 위 3 조건 중 2개 이상 충족 → **High** 위험군

**해석 포인트**: 위험군 비율 + 평균 출고가(원래 ARPU 추정) + 평균 충성도. 권장 액션은 "기변 프로모션 / 결합 상품 권유 / 보험 가입 유도".

---

## P2. 충성도 분석 (Brand Loyalty)

**언제 사용**: "충성 고객 분석", "브랜드별 충성도", "Top loyal customers".

**핵심 컬럼**: `Brand_Loyalty_Score`(1~10), `Manufacturer`, `Avg_Replacement_Cycle_Months`, `Bundling_Status`.

**분석 축**:
- 제조사 × 평균 충성도 점수
- 충성도 5분위(`NTILE(5)`) × 평균 교체 주기 × 결합 상품 가입율
- 충성도 ≥ 8 인 **앵커 고객** 의 단말 가격대 분포

**해석 포인트**: "충성도 + 결합 상품" 더블 락인은 이탈률을 크게 낮춥니다. 앵커 고객은 신모델 출시 직후 업셀 타깃.

---

## P3. 단말 사용 패턴 (Data / App / Time)

**언제 사용**: "데이터 사용 패턴", "헤비 유저", "야간 사용자", "앱 카테고리별 분석".

**핵심 컬럼**: `Avg_Data_Usage_GB`, `Tethering_Usage_GB`, `Wi_Fi_Ratio_Pct`, `Peak_Usage_Time`, `Top_App_Category`.

**분석 축**:
- 데이터 사용량 백분위(P50/P90/P99) × 앱 카테고리
- Wi-Fi 의존도가 낮은(`Wi_Fi_Ratio_Pct < 30`) 셀룰러 헤비 유저 추출
- 피크 시간대(`Peak_Usage_Time` 22:00~02:00) 야간 사용자 비율

**해석 포인트**: 셀룰러 헤비 유저는 **무제한/대용량 요금제 업셀 타깃**, 야간 비디오/게임 사용자는 **콘텐츠 제휴/번들** 타깃.

---

## P4. 번들/보조금 효과 분석

**언제 사용**: "번들링 가입 영향", "결합 상품 효과", "보조금 종류별 차이".

**핵심 컬럼**: `Bundling_Status`, `Subsidy_Type`, `Avg_Data_Usage_GB`, `Brand_Loyalty_Score`, `Months_in_Use`.

**분석 축**:
- `Bundling_Status` × 평균 사용 개월 × 평균 충성도
- `Subsidy_Type` × 약정 종료 임박 비율(`Months_in_Use >= 22`)
- 결합 상품(`Family` / `Internet+TV`) 가입자의 **재가입 잠재력** = 보험·중고보상 가입율

**해석 포인트**: `Family` / `Internet+TV` 가입자는 평균 사용 개월이 길고 충성도가 높습니다. 비결합(`Single`) 가입자가 이탈 표적.

---

## P5. 단말 교체 주기 / 연식 분석

**언제 사용**: "교체 주기 분석", "노후 단말", "기변 임박 고객", "device age".

**핵심 컬럼**: `Months_in_Use`, `Avg_Replacement_Cycle_Months`, `Battery_Health_Pct`, `Repair_History_Count`.

**분석 축**:
- `Months_in_Use` ≥ `Avg_Replacement_Cycle_Months` 인 고객 = **이미 교체 주기 초과**
- `Battery_Health_Pct` 5단계 버킷(<70 / 70~80 / 80~90 / 90~95 / 95+) × 평균 수리 횟수
- 제조사별 평균 사용 개월 비교

**해석 포인트**: 교체 주기 초과 + 배터리 80 미만 + 수리 2회 이상 = **확실한 기변 타깃**.

---

## P6. 채널/구매 행태 분석

**언제 사용**: "채널별 고객 분포", "온라인 vs 매장", "보조금 채널 차이".

**핵심 컬럼**: `Preferred_Channel`, `Subsidy_Type`, `Device_Insurance`, `Trade_in_Program`.

**분석 축**:
- 채널별 평균 출고가(고가/중저가 단말 선호 차이)
- 채널 × 보조금 유형 매트릭스 (count + 평균 단말가)
- 채널별 보험/중고보상 가입율

**해석 포인트**: 직영점(`Direct Store`)은 고가 단말 + 보험 가입율이 높고, 온라인(`Online Shop`)은 자가 검색형 가성비 고객.

---

## P7. 제조사/모델 비교

**언제 사용**: "삼성 vs 애플", "제조사별 평균 사용량", "모델별 충성도".

**핵심 컬럼**: `Manufacturer`, `Model_Name`, `Brand_Loyalty_Score`, `Avg_Data_Usage_GB`, `Battery_Health_Pct`, `Repair_History_Count`.

**분석 축**:
- 제조사 × 평균 충성도 / 평균 데이터 사용량 / 평균 배터리 / 평균 수리 횟수
- 모델별 점유율(상위 5개 모델)
- 제조사 × 결합 상품 가입율

**해석 포인트**: 만약 특정 제조사의 평균 수리 횟수가 두드러지면 품질/AS 이슈 지표로 본문에 명시.

---

## 분석 흐름 권장 시퀀스

1. **세션 첫 호출**: `get-table-schema` 로 컬럼 확인 (1회).
2. **분석 주제 확정**: 사용자 질문을 위 P1~P7 중 하나(또는 2~3개 조합)에 매핑.
3. **쿼리 실행**: `sql-cookbook.md` 에서 해당 패턴의 SQL을 출발점으로 `run-sql` 호출. 필요시 필터 추가.
4. **요약 추출**: 핵심 KPI 4~6개 + 세그먼트 비교 표 + 인사이트 3개 + 권장 액션 2~3개.
5. **출력 분기**: `SKILL.md` 의 5번 단계 흐름을 따라 사용자에게 산출물 형식 확인.

## 흔한 실수

- **`COUNT(*)` 만 가져오고 분모를 안 적음** — 비율 해석이 어려워집니다. 항상 전체 대비 비중도 함께 계산.
- **`Battery_Health_Pct` 가 100 초과인 행 제외하지 않음** — 일부 측정 오차 행이 있습니다. 분석 목적에 따라 `WHERE Battery_Health_Pct <= 100` 필터를 추가.
- **`Months_in_Use = 0` 행 무시** — 신규 개통 직후라 사용량/충성도 해석에 부적합. 이탈 분석에서는 제외 권장.
- **표본 크기 미공지** — 1,000행 더미 데이터임을 결과 보고 시 1회 명시.
