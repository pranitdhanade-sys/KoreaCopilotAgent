---
name: telecom-customer-analysis
description: |
  Analyzes telecom customer device, plan, usage, and loyalty data from the Telecom DB MCP server
  and orchestrates downstream report generation. Use when the user asks to "통신 고객 분석",
  "통신사 고객 데이터 분석", "이탈 위험 고객", "단말 사용 패턴", "충성도 점수", "단말 교체 주기",
  "번들링 가입 영향", "제조사별 고객 분포", "telecom customer analysis", "churn risk", "device
  usage pattern", "brand loyalty", "subscriber segmentation", "carrier customer insight". Also
  use as the entry point whenever the user wants an HTML dashboard, Word report, PPT deck, or
  email summary that involves telecom customer data — this skill produces the underlying
  analysis and then routes to the appropriate output skill.
license: MIT
metadata:
  author: Microsoft Demo
  version: "1.0"
---

# Telecom Customer Analysis

## What This Skill Does

통신사 고객 33개 속성(단말 스펙, 사용량, 채널, 보조금, 번들, 충성도 등)을 담은 Telecom DB MCP를 호출하여 사용자의 분석 질문에 답하고, 결과를 사용자 선호에 맞는 산출물(HTML 대시보드 / Word / PPT / 채팅 요약 / 메일) 로 라우팅합니다.

본 스킬은 **분석 허브** 역할만 수행합니다. 산출물 생성은 다음 동료 스킬에 위임합니다.

- `telecom-dashboard-builder` — 반응형 HTML 대시보드
- `telecom-word-report` — Word(.docx) 보고서
- `telecom-ppt-report` — PowerPoint(.pptx) 보고서
- 메일 발송 — Cowork 내장 Outlook 기능에 직접 위임

## Connector Tools (telecom-db-mcp)

본 스킬은 `telecom-db-mcp` 커넥터에서 다음 4개 도구를 사용합니다. **항상 도구 이름을 그대로** 사용하세요.

| 도구 | 용도 | 우선순위 |
| --- | --- | --- |
| `get-table-schema` | `devices` 테이블 컬럼 + 5행 샘플. SQL 생성 전 grounding 용 | 1 (먼저 호출) |
| `get-device-stats` | manufacturer / network / OS 등 그룹별 집계(count, avg battery, avg price …) | 2 |
| `list-devices` | 단순 필터(제조사/모델/네트워크/OS/배터리)로 행 조회 | 2 |
| `run-sql` | 자유 형식 SELECT/WITH 쿼리(읽기 전용, 50,000행 캡). 복합 분석은 항상 이 도구 사용 | 3 |

> `run-sql` 은 `INSERT/UPDATE/DELETE/DROP/CREATE/ALTER/...` 가 거부됩니다. 단일 `SELECT` 또는 `WITH`만 허용.

## Workflow

### 1. 사용자 의도 분류

다음 3가지 축으로 의도를 정리합니다.

1. **분석 주제** (예시 매핑은 `references/analysis-patterns.md` 참조)
   - 이탈 위험 / 충성도 / 사용 패턴 / 세그멘테이션 / 번들·보조금 효과 / 단말 교체 주기 / 채널별 분포 / 배터리·연식 분석
2. **세부 필터** (제조사, 네트워크, OS, 사용 기간, 충성도 점수 범위 등)
3. **선호 산출물** — 사용자가 명시했다면 그대로, 아니라면 **분석 완료 후 5번 단계에서 질문**

### 2. 스키마 확인

세션에서 처음 호출하는 경우 먼저 `get-table-schema` 를 1회 호출하여 컬럼 이름·타입·샘플을 확보합니다. 이미 본 세션에서 확보했다면 재호출하지 마세요.

### 3. 데이터 수집

복잡도에 따라 도구를 선택합니다.

- 단일 그룹 집계 → `get-device-stats`
- 필터링된 원시 행 미리보기 → `list-devices`
- 다단계 집계, CTE, 백분위, 세그멘테이션 → `run-sql`

`run-sql` 사용 시:

- `references/sql-cookbook.md` 의 검증된 쿼리를 출발점으로 사용하세요.
- 쿼리는 단일 `SELECT` 또는 `WITH ... SELECT` 한 문장으로 작성.
- 행 수가 큰 결과는 **요약 통계 + 상위 N행** 으로 좁혀서 가져옵니다(컨텍스트 토큰 절약).

### 4. 인사이트 추출

데이터에서 다음을 도출합니다.

- **핵심 KPI 4~6개** — 평균/중앙값/세그먼트 크기 등. 숫자는 단위와 함께(GB, %, 원, 개월).
- **2~4개의 의미 있는 비교** — 세그먼트 간 차이, 시간 흐름, 임계치 초과 비율.
- **권장 액션 2~3개** — 데이터에 근거한 마케팅/리텐션/CS 액션.

해석 가이드는 `references/analysis-patterns.md` 참고.

### 5. 산출물 형식 선택 (사용자가 명시하지 않은 경우)

사용자에게 다음과 같이 묻습니다:

> 분석 결과를 어떤 형태로 받아보시겠어요?
> 1. 채팅 요약만
> 2. 반응형 HTML 웹 대시보드 (`telecom-dashboard-builder`)
> 3. Word 보고서 (`telecom-word-report`)
> 4. PowerPoint 슬라이드 (`telecom-ppt-report`)
> 5. 위 결과를 메일로 발송

사용자가 처음 질문할 때 이미 형식을 지정했다면 (예: "PPT로 만들어줘") 묻지 말고 바로 해당 단계로 진행합니다.

### 6. 산출물 생성 및 라우팅

| 사용자 선택 | 처리 |
| --- | --- |
| 채팅 요약만 | 아래 **출력 형식** 섹션의 마크다운 요약 그대로 응답 |
| HTML 대시보드 | `telecom-dashboard-builder` 스킬에 분석 컨텍스트(KPI/차트 데이터/권장 액션) 전달 |
| Word | `telecom-word-report` 스킬에 동일 컨텍스트 전달 |
| PPT | `telecom-ppt-report` 스킬에 동일 컨텍스트 전달 |
| 메일 발송 | 먼저 위 산출물 중 하나(또는 채팅 요약)를 생성 → 사용자에게 수신자/제목 확인 → **Cowork 내장 Outlook 기능**으로 본문/첨부 구성하여 발송. 본 스킬 안에서 메일 본문을 직접 작성하지 말고 내장 기능에 위임 |

## 출력 형식 (채팅 요약 / 다른 스킬에 전달할 공통 페이로드)

분석을 마치면 항상 다음 구조의 마크다운을 산출합니다. 이 구조가 다른 출력 스킬이 기대하는 **공통 페이로드** 입니다.

```markdown
## 분석 개요
- **분석 주제**: <한 줄>
- **데이터 기간/범위**: <필터>
- **표본 크기**: <N 명/대>
- **데이터 출처**: Telecom DB MCP (`devices` 테이블, 33 컬럼)

## 핵심 KPI
| 지표 | 값 | 비고 |
| --- | --- | --- |
| ... | ... | ... |

## 세그먼트별 비교
| 세그먼트 | 인원 | 핵심 지표 1 | 핵심 지표 2 |
| --- | --- | --- | --- |
| ... | ... | ... | ... |

## 주요 인사이트
1. ...
2. ...
3. ...

## 권장 액션
- **리텐션**: ...
- **업셀**: ...
- **CS**: ...

## 사용된 쿼리
```sql
-- run-sql 호출에 사용한 SELECT
SELECT ...
```
```

## Additional Resources

추가 컨텍스트는 필요할 때만 로드합니다.

- **`references/data-schema.md`** — 33개 컬럼의 한국어 의미·단위·예시값. SQL 작성 전이나 사용자가 "어떤 데이터가 있어요?" 라고 물을 때 로드.
- **`references/analysis-patterns.md`** — 7개 대표 분석 시나리오(이탈/충성/번들/배터리/채널/연식/사용량)와 해석 가이드. 분석 주제를 매핑할 때 로드.
- **`references/sql-cookbook.md`** — `run-sql` 에 바로 넣을 수 있는 검증된 SELECT 쿼리 모음. 복합 분석을 시작할 때 로드.

## 가드레일

- **PII 가정 금지**: `Customer_ID` 는 유사 익명 식별자입니다. 실제 인물을 추정하거나 외부 매핑을 시도하지 마세요.
- **쓰기 작업 금지**: MCP 서버는 읽기 전용입니다. `INSERT/UPDATE/DELETE/DDL` 시도하지 마세요(어차피 거부됨).
- **데이터 한계 공지**: 표본 1,000행 더미 데이터임을 인사이트 보고 시 1회 명시.
- **단위 표기 필수**: 모든 수치에 단위를 붙입니다(GB / % / 원 / 개월 / 회).
- **소스 인용**: 마지막에 사용한 `run-sql` 쿼리를 출력에 반드시 포함(재현성).
