# Dashboard HTML Template

`telecom-dashboard-builder` 가 사용하는 완성형 HTML 골격입니다. 아래 자리 표시자(`__...__`)를 분석 페이로드로 치환하여 단일 `.html` 파일을 만듭니다.

## 자리 표시자

| 자리 표시자 | 채우는 값 |
| --- | --- |
| `__TITLE__` | 보고서 제목 (예: "통신사 고객 이탈 위험 분석") |
| `__GENERATED_AT__` | 생성 일시 (예: "2026-05-20 15:30 KST") |
| `__SAMPLE_SIZE__` | 표본 크기 (예: "1,000명") |
| `__SCOPE__` | 필터/범위 한 줄 (예: "전체 가입자 · 5G + LTE") |
| `__KPI_CARDS__` | KPI 카드 HTML 블록 (아래 패턴 반복) |
| `__CHART_BLOCKS__` | 차트 카드 HTML 블록 (아래 패턴 반복) |
| `__SEGMENT_TABLE_HEAD__` | `<thead>` 안 `<th>` 셀들 |
| `__SEGMENT_TABLE_BODY__` | `<tbody>` 안 `<tr>` 행들 |
| `__INSIGHTS_LIST__` | `<ol>` 안 `<li>` 인사이트들 |
| `__ACTION_CARDS__` | 액션 카드 블록 |
| `__SQL_USED__` | 사용된 SELECT 쿼리(`<pre>` 안에 들어감) |
| `__CHART_SCRIPTS__` | 각 차트의 `new Chart(...)` 초기화 코드 (한 차트당 1블록) |

## KPI 카드 패턴

```html
<div class="kpi-card">
  <div class="kpi-value">41.2 <span class="kpi-unit">GB</span></div>
  <div class="kpi-label">월평균 데이터 사용량</div>
  <div class="kpi-sub">전 분기 대비 +5.3%</div>
</div>
```

## 차트 카드 패턴

```html
<div class="chart-card">
  <h3 class="chart-title">제조사별 평균 충성도</h3>
  <canvas id="chartManufacturerLoyalty"></canvas>
  <p class="chart-caption">Samsung이 평균 7.4점으로 최고, Xiaomi가 5.8점으로 최저.</p>
</div>
```

## 차트 스크립트 패턴

```js
new Chart(document.getElementById('chartManufacturerLoyalty'), {
  type: 'bar',
  data: {
    labels: ['Samsung','Apple','Xiaomi','Google'],
    datasets: [{
      label: '평균 충성도',
      data: [7.4, 7.1, 5.8, 6.5],
      backgroundColor: ['#0078D4','#2B88D8','#106EBE','#005A9E']
    }]
  },
  options: {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: { y: { beginAtZero: true, max: 10 } }
  }
});
```

## 액션 카드 패턴

```html
<div class="action-card action-retention">
  <div class="action-tag">리텐션</div>
  <div class="action-text">결합 미가입 + 충성도 5 이하 세그먼트 1,234명에게 Family 결합 프로모션 발송</div>
</div>
```

> 액션 카드는 `action-retention` / `action-upsell` / `action-cs` 클래스로 색을 다르게.

## 전체 HTML 골격

```html
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>__TITLE__ · Telecom Insights</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <style>
    :root {
      --primary: #0078D4;
      --primary-dark: #106EBE;
      --primary-light: #2B88D8;
      --bg: #FAF9F8;
      --surface: #FFFFFF;
      --text: #201F1E;
      --text-muted: #605E5C;
      --border: #EDEBE9;
      --warning: #D83B01;
      --success: #107C10;
      --accent: #5C2D91;
    }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; background: var(--bg); color: var(--text);
      font-family: 'Segoe UI', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
      line-height: 1.5; }
    header.app-header {
      background: linear-gradient(135deg, var(--primary), var(--primary-dark));
      color: #fff; padding: 32px 40px;
    }
    header.app-header h1 { margin: 0 0 8px; font-size: 28px; font-weight: 600; }
    header.app-header .meta { font-size: 13px; opacity: 0.9; }
    main { padding: 24px 40px 80px; max-width: 1400px; margin: 0 auto; }
    section { margin-top: 32px; }
    section h2 {
      font-size: 18px; font-weight: 600; margin: 0 0 16px;
      padding-bottom: 8px; border-bottom: 2px solid var(--border);
    }
    .kpi-grid {
      display: grid; gap: 16px;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    }
    .kpi-card {
      background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
      padding: 20px; box-shadow: 0 1px 2px rgba(0,0,0,0.04);
    }
    .kpi-value { font-size: 28px; font-weight: 700; color: var(--primary); }
    .kpi-unit  { font-size: 14px; font-weight: 500; color: var(--text-muted); margin-left: 4px; }
    .kpi-label { font-size: 13px; color: var(--text-muted); margin-top: 4px; }
    .kpi-sub   { font-size: 12px; color: var(--success); margin-top: 8px; }
    .chart-grid {
      display: grid; gap: 16px;
      grid-template-columns: repeat(auto-fit, minmax(420px, 1fr));
    }
    .chart-card {
      background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
      padding: 20px; box-shadow: 0 1px 2px rgba(0,0,0,0.04);
    }
    .chart-card h3 { margin: 0 0 12px; font-size: 15px; font-weight: 600; }
    .chart-card canvas { max-height: 280px; }
    .chart-caption { font-size: 12px; color: var(--text-muted); margin: 12px 0 0; }
    table.segment-table {
      width: 100%; border-collapse: collapse; background: var(--surface);
      border: 1px solid var(--border); border-radius: 8px; overflow: hidden;
    }
    table.segment-table th, table.segment-table td {
      padding: 10px 14px; text-align: left; font-size: 13px;
      border-bottom: 1px solid var(--border);
    }
    table.segment-table thead th { background: #F3F2F1; font-weight: 600; position: sticky; top: 0; }
    table.segment-table tbody tr:nth-child(even) { background: #FAFAFA; }
    .insights ol { padding-left: 24px; }
    .insights li { margin-bottom: 8px; }
    .action-grid {
      display: grid; gap: 12px;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    }
    .action-card {
      padding: 16px; border-radius: 8px; background: var(--surface);
      border-left: 4px solid var(--primary);
    }
    .action-retention { border-left-color: var(--primary); }
    .action-upsell    { border-left-color: var(--accent); }
    .action-cs        { border-left-color: var(--warning); }
    .action-tag {
      display: inline-block; font-size: 11px; font-weight: 600; text-transform: uppercase;
      color: var(--text-muted); margin-bottom: 6px; letter-spacing: 0.5px;
    }
    .action-text { font-size: 14px; }
    details.sql-used { margin-top: 16px; }
    details.sql-used summary { cursor: pointer; font-size: 13px; color: var(--text-muted); }
    details.sql-used pre {
      background: #1E1E1E; color: #D4D4D4; padding: 16px; border-radius: 8px;
      overflow-x: auto; font-family: 'Cascadia Code', 'Consolas', monospace; font-size: 12px;
    }
    footer.app-footer {
      text-align: center; padding: 24px; color: var(--text-muted); font-size: 12px;
      border-top: 1px solid var(--border); margin-top: 48px;
    }
    @media (max-width: 720px) {
      header.app-header { padding: 24px; }
      main { padding: 16px; }
      .chart-grid { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <header class="app-header">
    <h1>__TITLE__</h1>
    <div class="meta">생성: __GENERATED_AT__ · 표본: __SAMPLE_SIZE__ · 범위: __SCOPE__ · 출처: Telecom DB MCP</div>
  </header>

  <main>
    <section>
      <h2>핵심 KPI</h2>
      <div class="kpi-grid">__KPI_CARDS__</div>
    </section>

    <section>
      <h2>분석 차트</h2>
      <div class="chart-grid">__CHART_BLOCKS__</div>
    </section>

    <section>
      <h2>세그먼트 비교</h2>
      <table class="segment-table">
        <thead><tr>__SEGMENT_TABLE_HEAD__</tr></thead>
        <tbody>__SEGMENT_TABLE_BODY__</tbody>
      </table>
    </section>

    <section class="insights">
      <h2>주요 인사이트</h2>
      <ol>__INSIGHTS_LIST__</ol>
    </section>

    <section>
      <h2>권장 액션</h2>
      <div class="action-grid">__ACTION_CARDS__</div>
    </section>

    <section>
      <h2>참고</h2>
      <details class="sql-used">
        <summary>사용된 SQL 쿼리 보기</summary>
        <pre>__SQL_USED__</pre>
      </details>
    </section>
  </main>

  <footer class="app-footer">Generated by Cowork · Telecom Customer Insights Plugin</footer>

  <script>
  __CHART_SCRIPTS__
  </script>
</body>
</html>
```

## 차트 색 팔레트 권장

- 단색 시리즈: `#0078D4`, `#2B88D8`, `#106EBE`, `#005A9E`
- 카테고리 비교(4~6개): `#0078D4`, `#5C2D91`, `#107C10`, `#D83B01`, `#FFB900`, `#038387`
- 위험 등급(Low/Med/High): `#107C10`, `#FFB900`, `#D83B01`
